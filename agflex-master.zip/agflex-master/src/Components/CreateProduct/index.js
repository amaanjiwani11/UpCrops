import React from "react";
import { useFormik } from "formik";
import { postResponse } from "../../services/API/CommonAPI";

const admin = JSON.parse(localStorage.getItem("login"));

const CreateProductForm = () => {
  
  const formik = useFormik({
    initialValues: {
      name: "",
      price: "",
      description: "",
      category: "",
      // image: null,
      // imagePreview: null,
    },
    onSubmit: async (values) => {
      console.log(values);
      let data = {
        name: values.name,
        description: values.description,
        spec: values.description,
        price: values.price,
        uid: admin?.admin?._id,
      };
      await postResponse("product/addProduct", data);

      window.location.href = "Products";
      formik.resetForm();
    },
  });

  return (
    <div className="max-w-md mx-auto mt-160 mb-160">
      <form
        onSubmit={formik.handleSubmit}
        className="bg-white shadow-md rounded px-8 pt-6 pb-8"
      >
        <div className="mb-6">
          <label
            className="block text-gray-700 text-sm font-bold mb-2"
            htmlFor="name"
          >
            Name
          </label>
          <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="name"
            type="text"
            name="name"
            value={formik.values.name}
            onChange={formik.handleChange}
            required
          />
        </div>
        <div className="mb-6">
          <label
            className="block text-gray-700 text-sm font-bold mb-2"
            htmlFor="price"
          >
            Price
          </label>
          <div className="relative">
            <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-700 font-bold">
              $
            </span>
            <input
              className="pl-15 shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              id="price"
              type="number"
              name="price"
              value={formik.values.price}
              onChange={formik.handleChange}
              required
            />
          </div>
        </div>
        <div className="mb-6">
          <label
            className="block text-gray-700 text-sm font-bold mb-2"
            htmlFor="description"
          >
            Description
          </label>
          <textarea
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline h-32 resize-none"
            id="description"
            name="description"
            value={formik.values.description}
            onChange={formik.handleChange}
            required
          ></textarea>
        </div>
        <div className="mb-6">
          {/* <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="image">
            Image
          </label>
         <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="image"
            type="file"
            name="image"
            accept="image/*"
            onChange={(event) => {
              formik.setFieldValue("image", event.currentTarget.files[0]);
              formik.setFieldValue("imagePreview", URL.createObjectURL(event.currentTarget.files[0]));
            }}
            required
          />
          {formik.values.imagePreview && (
            <img src={formik.values.imagePreview} alt="Preview" className="mt-3 rounded" style={{ maxWidth: '100%' }} />
          )} */}
        </div>
        <div className="flex items-center justify-center">
          <button
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
            type="submit"
          >
            Create Product
          </button>
        </div>
      </form>
    </div>
  );
};

export default CreateProductForm;
