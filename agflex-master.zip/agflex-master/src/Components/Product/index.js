import moment from "moment";
import React, { useEffect, useState } from "react";
import { Accordion, Button, Form } from "react-bootstrap";
import { Link, useHistory, useLocation } from "react-router-dom";
import { getResponse, postResponse } from "../../services/API/CommonAPI";
import { GlobalContext } from "../../context/States/GlobalState";
import Pagination from "../Pagination";

export default function ProductPage() {
  const { Global } = React.useContext(GlobalContext);
  const login =
    typeof Global.login == "string" ? JSON.parse(Global.login) : Global.login;

  const history = useHistory();
  const search = useLocation().search;
  // const location = useLocation().state?.location;
  // const job_role = useLocation().state?.job_role;
  const job_role = new URLSearchParams(search).get("job_role");
  const location = new URLSearchParams(search).get("location");
  const currPage = isNaN(history.location?.state?.page)
    ? 1
    : history.location?.state?.page ?? 1;
  const currRole =
    history.location?.state?.role !== ("undefined" || false || undefined)
      ? history.location?.state?.role
      : undefined;
  const currCity =
    history.location?.state?.city !== ("undefined" || false || undefined)
      ? history.location?.state?.city
      : undefined;
  const [state, setState] = React.useState({
    
  });
  const [role, setRoleState] = React.useState(currRole ?? job_role ?? "");
  const [City, setCityState] = React.useState(currCity ?? location ?? "");
  const [FilterSubmit, setFilterSubmit] = React.useState(
    history.location?.state?.searchQuery
  );
  const [Filter, setFilter] = React.useState({
    contract: [
      "Bank",
      "Agency",
      "Permanent",
      "Ad Hoc",
      "Temporary",
      "Part Time",
      "Contractual",
    ].fill(false),
    exp_level: [
      "New",
      "Beginner",
      "Student",
      "Novice",
      "Advanced Beginner",
      "Intermediate",
      "Experienced",
      "Expert",
      "No Preference",
    ].fill(false),
    // skill: new Array(skillArray.length).fill(false),
    date: undefined,
  });
  const [products, setProducts] = useState([]);
  const handleSubmit = async (i) => {
    const response = await postResponse(
      `/cart/addCart`,
      {
        "uid": Global?.login?.admin?._id,
        "product":[
            {
                "pid":i,
                "quantity": 1
            }
        ]
    }
    );
    if (response.status === "success") {
      setState((state) => ({
        ...state,
        activePage: 1,
        jobData: response.data,
      }));
    }
    return response;
  };

  const handleSearchChange = async () => {
    const contract = [];
    const exp_level = [];
    const skill = [];
    [
      "Bank",
      "Agency",
      "Permanent",
      "Ad Hoc",
      "Temporary",
      "Part Time",
      "Contractual",
    ].map((item) => {
      FilterSubmit?.contract?.includes(item)
        ? contract.push(true)
        : contract.push(false);
    });
    setFilter((e) => ({ ...e, contract: contract }));

    [
      "New",
      "Beginner",
      "Student",
      "Novice",
      "Advanced Beginner",
      "Intermediate",
      "Experienced",
      "Expert",
      "No Preference",
    ].map((item) => {
      FilterSubmit?.exp_level?.includes(item)
        ? exp_level.push(true)
        : exp_level.push(false);
    });
    setFilter((e) => ({ ...e, exp_level: exp_level }));
    // skillArray.map((e) => {
    //   FilterSubmit?.skill?.includes(e.value)
    //     ? skill.push(true)
    //     : skill.push(false);
    // });
    setFilter((e) => ({ ...e, skill: skill }));

    setFilter((e) => ({ ...e, date: FilterSubmit?.date }));
  };

  const handleOnChange = async (position) => {
    const updatedCheckedState = Filter.contract.map((item, index) =>
      index === position ? !item : item
    );
    setFilter((e) => ({ ...e, contract: updatedCheckedState }));
  };

  const handleExpOnChange = async (position) => {
    const updatedCheckedState = Filter.exp_level.map((item, index) =>
      index === position ? !item : item
    );
    setFilter((e) => ({ ...e, exp_level: updatedCheckedState }));
  };

  const handleSkillOnChange = async (position) => {
    const updatedCheckedState = Filter.skill.map((item, index) =>
      index === position ? !item : item
    );
    await setFilter((e) => ({ ...e, skill: updatedCheckedState }));
  };

  const getPostSubmit = async () => {
    let queryString = ``;
    if (FilterSubmit?.contract?.length > 0) {
      queryString += `&contract=${JSON.stringify(FilterSubmit?.contract)}`;
    }
    if (FilterSubmit?.exp_level?.length > 0) {
      queryString += `&exp_level=${JSON.stringify(FilterSubmit?.exp_level)}`;
    }
    if (FilterSubmit?.skill?.length > 0) {
      queryString += `&skill=${FilterSubmit?.skill}`;
    }
    if (FilterSubmit?.date !== undefined) {
      queryString += `&d=${FilterSubmit?.date}`;
    }
    if (role !== (undefined || null)) {
      queryString += `&job_role=${role}`;
    }
    if (City !== (undefined || null)) {
      queryString += `&location=${City}`;
    }
    if (login?.user_type?.userType == 1) {
      queryString += `&nurse_id=${login.id}`;
    }
    const response = await getResponse(
      `/jobs/all?page=${state.activePage}${queryString}`,
      {}
    );
    if (response.status === "success") {
      setState({
        ...state,
        jobData: response.data,
      });
    }
    if (response.status === "error") {
      setState({ ...state, jobDetailData: false });
    }
    return response;
  };

  const handlePageChange = async (pageNumber) => {
    let queryString = ``;
    if (FilterSubmit?.contract?.length > 0) {
      queryString += `&contract=${JSON.stringify(FilterSubmit?.contract)}`;
    }
    if (FilterSubmit?.exp_level?.length > 0) {
      queryString += `&exp_level=${JSON.stringify(FilterSubmit?.exp_level)}`;
    }
    if (FilterSubmit?.skill?.length > 0) {
      queryString += `&skill=${FilterSubmit?.skill}`;
    }
    if (FilterSubmit?.date !== undefined) {
      queryString += `&d=${FilterSubmit?.date}`;
    }
    if (role !== undefined) {
      queryString += `&job_role=${role}`;
    }
    if (City !== undefined) {
      queryString += `&location=${City}`;
    }
    if (login?.user_type?.userType == 1) {
      queryString += `&nurse_id=${login.id}`;
    }
    const queryURL =
      login?.user_type?.userType != 1
        ? `/jobs/all?page=${pageNumber}`
        : `/jobs/all?page=${pageNumber}&nurse_id=${login.id}`;
    const response =
      Boolean(FilterSubmit) || Boolean(role) || Boolean(City)
        ? await getResponse(
            `/jobs/all?d=${
              FilterSubmit?.date ?? 0
            }&page=${pageNumber}${queryString}`,
            {}
          )
        : await getResponse(queryURL, {});

    if (response.status === "success") {
      setState((state) => ({ ...state, jobData: response.data }));
      setState((prev) => ({ ...prev, activePage: pageNumber }));
    }
    return response;
  };


  const [count, setCount] = React.useState([]);

  const incrementCount = (i) => {
    setCount(count[i] + 1);
  };

  const decrementCount = (i) => {
    setCount(count[i] - 1);
  };

  const getProducts = async () => {
    const data = await getResponse(`product/getProduct/`);
    setProducts(data?.payload?.product || []);
  };

  useEffect(() => {
    getProducts();
  }, []);
  return (
    <section>
      {/* <div className="Page_Banner Post_new_job">
         <div className="container h-100">
          <div className="d-flex align-items-center justify-content-center h-100 flex-column">
            <h2 className="text-white fs-1 fw-bold"> Jobs List</h2>
            <nav aria-label="breadcrumb ">
              <ol className="breadcrumb mb-0 mt-15">
                <li className="breadcrumb-item">
                  <Link to="/">Home</Link>
                </li>
                <li className="breadcrumb-item active" aria-current="page">
                  Jobs List
                </li>
              </ol>
            </nav>
          </div>
        </div> 
      </div> */}
      <div className="JobList mt-130 mb-50 h-100">
        <div className="container">
          <div className="row g-4">
            
              {products.map((product, i) => {
                console.log(product)
                return (
                  <>
                    <div className="row g-4 mt-10">
                      <div
                        key={`${i.toString()}_card`}
                        id={`${i}_card`}
                        className="col-xl-4 col-lg-12 col-12"
                      >
                        <div
                          // to={{
                          //   pathname: `/JobDetails/${value.id}`,

                          // }}
                          className="Single_Job_list_Card"
                        >
                          <h5 className="fw-bold">{product?.name}</h5>
                          <p className="mt-10">{product?.description}</p>
                          <div className="mt-15  Job_Info">
                          <span>Price: ${product?.price}</span>
                          
                          {/* <div className="flex items-center border-gray-100">
                            <span className="cursor-pointer rounded-l bg-gray-100 py-1 px-3.5 duration-100 hover:bg-blue-500 hover:text-blue-50" onClick={()=>decrementCount(i)}> - </span>
                            <input className="h-8 w-8 border bg-white text-center text-xs outline-none" type="number" value={count} min="0" />
                            <span className="cursor-pointer rounded-r bg-gray-100 py-1 px-3 duration-100 hover:bg-blue-500 hover:text-blue-50" onClick={()=>incrementCount(i)}> + </span>
                          </div> */}
                          <Button className="CommonButton" onClick={()=>handleSubmit(product?._id)}>Add to Cart</Button>
                          </div>
                        </div>
                      </div>
                    </div>
                    {/* <div className="row g-4 mb-50 mt-50">
                      <div className="col-12">
                        <Pagination
                          limit={state.limit}
                          activePage={state.activePage}
                          data={state?.jobData}
                          handlePageChange={handlePageChange}
                        />
                      </div>
                    </div> */}
                  </>
                );
              })}
            </div>
          </div>
      </div>
    </section>
  );
}
